
  import React from "react"
  import Component from "/Users/ananddharne/reactPortfolio/src/layouts/index.js"
  import data from "/Users/ananddharne/reactPortfolio/.cache/json/layout-index.json"

  export default (props) => <Component {...props} {...data} />
  