import fontawesome from '@fortawesome/fontawesome';
import FontAwesomeIcon from '@fortawesome/react-fontawesome';
import fabGithub from '@fortawesome/fontawesome-free-brands/faGithub';
import fasExternalLinkAlt from '@fortawesome/fontawesome-free-solid/faExternalLinkAlt';

fontawesome.library.add(fabGithub, fasExternalLinkAlt);
