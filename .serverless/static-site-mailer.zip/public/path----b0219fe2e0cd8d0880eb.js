webpackJsonp([60335399758886],{99:function(t,a){t.exports={data:{site:{siteMetadata:{title:"Anand's Portfolio"}}},layoutContext:{}}}});
//# sourceMappingURL=path----b0219fe2e0cd8d0880eb.js.map